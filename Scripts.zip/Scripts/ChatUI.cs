using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class ChatUI : MonoBehaviour {
    [SerializeField] private GeminiManager geminiManager;
    [SerializeField] private TMP_Text responseText;
    
    // Replace the single button with three buttons
    [SerializeField] private Button prompt1Button;
    [SerializeField] private Button prompt2Button;
    [SerializeField] private Button prompt3Button;
    
    // Dictionary for prompts
    private readonly Dictionary<string, string> availablePrompts = new Dictionary<string, string> {
        {"1", "Hello World"},
        {"2", "I am Gemini"},
        {"3", "I Love VR!"}
    };

    private void Start() {
        // Connect to Gemini Manager
        if (geminiManager != null) {
            geminiManager.OnChatResponseReceived += HandleResponse;
        }
        
        // Set up button listeners
        if (prompt1Button != null) {
            prompt1Button.onClick.AddListener(() => SendPrompt("1"));
        }
        
        if (prompt2Button != null) {
            prompt2Button.onClick.AddListener(() => SendPrompt("2"));
        }
        
        if (prompt3Button != null) {
            prompt3Button.onClick.AddListener(() => SendPrompt("3"));
        }
        
        // Initial response text
        if (responseText != null) {
            responseText.text = "Select one of the objects below to get help!";
        }
    }
    
    // Method for sending prompts by number
    public void SendPrompt(string promptNumber) {
        if (availablePrompts.ContainsKey(promptNumber)) {
            Debug.Log("Sending prompt: " + promptNumber);
            responseText.text = "Asking Gemini...";
            geminiManager.SendPrompt(promptNumber);
        }
    }

    private void HandleResponse(string response) {
        if (responseText != null) {
            Debug.Log("Response received: " + response);
            responseText.text = response;
            StartCoroutine(AnimateTextAppearance());
        }
    }

    private IEnumerator AnimateTextAppearance() {
        if (responseText != null) {
            string finalText = responseText.text;
            responseText.text = "";
            for (int i = 0; i <= finalText.Length; i++) {
                responseText.text = finalText.Substring(0, i);
                yield return new WaitForSeconds(0.02f);
            }
        }
    }

    private void OnDestroy() {
        if (geminiManager != null) {
            geminiManager.OnChatResponseReceived -= HandleResponse;
        }
        
        if (prompt1Button != null) {
            prompt1Button.onClick.RemoveListener(() => SendPrompt("1"));
        }
        
        if (prompt2Button != null) {
            prompt2Button.onClick.RemoveListener(() => SendPrompt("2"));
        }
        
        if (prompt3Button != null) {
            prompt3Button.onClick.RemoveListener(() => SendPrompt("3"));
        }
    }
}
