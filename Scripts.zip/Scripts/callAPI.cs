using UnityEngine;
using UnityEngine.Networking;
using TMPro;
using System.Collections;

public class callAPI : MonoBehaviour
{

    public TMP_Text questionText;
    public bool answering;

    // API URLs
    private string startSession = "http://localhost:8000/start-session";
    private string nextQuestion = "http://localhost:8000/next-question/";
    //private string submitAnswer = "http://localhost:8000/submit-answer/";

    private string sessionID;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        StartCoroutine(StartQuiz());
    }

    private IEnumerator StartQuiz()
    {
        //Get session ID
        UnityWebRequest startRequest = UnityWebRequest.Post(startSession, "");
        yield return startRequest.SendWebRequest();

        if (startRequest.result == UnityWebRequest.Result.Success)
        {
            // Parse session ID from the response
            string jsonResponse = startRequest.downloadHandler.text;
            SessionData sessionData = JsonUtility.FromJson<SessionData>(jsonResponse);
            sessionID = sessionData.session_id;

            StartCoroutine(GetNextQuestion(sessionID));

            // IMPLEMENTING ANSWER SUBMISSION
            /*for i in range 10:
                // Get next question
                StartCoroutine(GetNextQuestion(sessionID));

                answering = true
                while answering = true
                {
                    if()
                    {

                        answering = false
                    }
                }*/


        }
        else
        {
            Debug.LogError("Error: " + startRequest.error);
        }
    }

   private IEnumerator GetNextQuestion(string sessionID)
    {
        string questionRequest = nextQuestion + sessionID;

        // Send GET request to the API
        UnityWebRequest request = UnityWebRequest.Get(questionRequest);
        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            // Parse response
            string jsonResponse = request.downloadHandler.text;
            QuestionData questionData = JsonUtility.FromJson<QuestionData>(jsonResponse);

            if (!string.IsNullOrEmpty(questionData.question_text))
            {
                // Update the TMP Text component with the question
                questionText.text = questionData.question_text;
                Debug.Log("Question: " + questionData.question_text);  // Debug line to check question
            }
            else
            {
                Debug.LogWarning("No question available");
                questionText.text = "No question available.";
            }
        }
        else
        {
            Debug.LogError("Error: " + request.error);
        }
    }

    // IMPLEMENTING ANSWER SUBMISSION
    /*private IEnumerator SendAnswer(string sessionID)
    {
        string answerURL = submitAnswer + sessionID;

        UnityWebRequest answerPost = UnityWebRequest.Post(answerURL);
        yield return answerPost.SendWebRequest();
    }*/

    [System.Serializable]
    public class SessionData
    {
        public string session_id;
    }

    [System.Serializable]
    public class QuestionData
    {
        public string question_text;
        public string answer;
    }

    [System.Serializable]
    public class AnswerData
    {
        public string correct_answer;
        int score;
    }
}
