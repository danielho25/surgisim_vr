using UnityEngine;

public class Instrument : MonoBehaviour
{
    private Vector3 originPosition;

    public UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable instrumentInteractable;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        originPosition = transform.position;
    }

    // Releases instrument from player's hand and resets its position
    public void ResetPosition()
    {
        if (instrumentInteractable.isSelected)
        {
            instrumentInteractable.interactionManager.SelectExit(instrumentInteractable.interactorsSelecting[0], instrumentInteractable);
        }

        transform.position = originPosition;
        transform.rotation = Quaternion.identity;
    }
}
