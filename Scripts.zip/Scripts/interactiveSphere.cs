using System.Collections;
using UnityEngine;

public class InteractiveSphere : MonoBehaviour {
    [SerializeField] private ChatUI chatUI;
    [SerializeField] private string promptNumber = "1";  // set to 1 as default
    private Renderer sphereRenderer;
    private Color originalColor;
    private bool isAnimating = false;
   
    private void Awake() {
        sphereRenderer = GetComponent<Renderer>();
        if (sphereRenderer != null) {
            originalColor = sphereRenderer.material.color;
        }
    }

    private void OnMouseEnter() {
        if (sphereRenderer != null && !isAnimating) {
            sphereRenderer.material.color = Color.yellow;
        }
    }

    private void OnMouseExit() {
        if(sphereRenderer != null && !isAnimating) {
            sphereRenderer.material.color = originalColor;
        }
    }
    
     private void OnMouseDown()
    {
        if (!isAnimating && chatUI != null) {
            chatUI.SendPrompt(promptNumber);
            StartCoroutine(PulseAnimation());
            Debug.Log("Sphere clicked - sending prompt #" + promptNumber);
        }
    }

    private IEnumerator PulseAnimation()
    {
        isAnimating = true;
        Vector3 originalScale = transform.localScale;
        Vector3 targetScale = originalScale * 1.2f;
        
        // Scale up
        float duration = 0.2f;
        float elapsed = 0;
        while (elapsed < duration)
        {
            transform.localScale = Vector3.Lerp(originalScale, targetScale, elapsed/duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        // Scale down
        elapsed = 0;
        while (elapsed < duration)
        {
            transform.localScale = Vector3.Lerp(targetScale, originalScale, elapsed/duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        transform.localScale = originalScale;
        sphereRenderer.material.color = originalColor;
        isAnimating = false;
    }
}

    