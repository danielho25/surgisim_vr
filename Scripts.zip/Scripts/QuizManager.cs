using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.Networking;
using System;
using Unity.VisualScripting;
// using Microsoft.MixedReality.Toolkit.UI;
// using Microsoft.MixedReality.Toolkit.Input;

public class QuizManager : MonoBehaviour {
    // create the ui elements needed for the quiz inputs
    public TMP_Text questionText;
    public TMP_InputField answerInput;
    public Button submitButton;
    public TMP_Text scoreText;
    public TMP_Text difficultyText;
    public TMP_Text feedbackText;

    public GameObject mrtkKeyboard; // Reference to the MRTK keyboard prefab
    private TouchScreenKeyboard virtualKeyboard;

    // configure the api for the quiz session
    public string apiURL = "http://127.0.0.1:8000";
    private string sessionID;
    private string currentQuestionID;
    private float questionStartTime;

    [Serializable]
public class SessionResponse
{
    public string session_id;
    public string message;
}

[Serializable]
public class QuestionResponse
{
    public string question_id;
    public string question_text;
    public int difficulty;
}

[Serializable]
public class AnswerRequest
{
    public string question_id;
    public string user_answer;
    public float response_time;
}

[Serializable]
public class AnswerResponse
{
    public bool is_correct;
    public string correct_answer;
    public int score;
    public int total_questions;
    public bool difficulty_changed;
    public int new_difficulty;
}

[Serializable]
public class EndSessionResponse
{
    public string session_id;
    public string final_score;
    public string score_percentage;
    public string session_duration;
    public int final_difficulty;
    public bool results_saved;
}

    void Start()
    {
        submitButton.onClick.AddListener(SubmitAnswer);
        StartCoroutine(StartSession());
    }

    IEnumerator StartSession() {
        // web request for start-session method from python api, matches the structure
        using (UnityWebRequest www = UnityWebRequest.PostWwwForm($"{apiURL}/start-session", " ")) {
            yield return www.SendWebRequest();
            if (www.result == UnityWebRequest.Result.Success) {
                string jsonResponse = www.downloadHandler.text;
                SessionResponse sessionResponse = JsonUtility.FromJson<SessionResponse>(jsonResponse);
                sessionID = sessionResponse.session_id;
                Debug.Log($"Session started with ID: {sessionID}");
                StartCoroutine(GetNextQuestion());  // start the next question route if the return is succesfull
            } else {
                Debug.LogError($"Error Starting Sesison: {www.error}");
                feedbackText.text = "Error connecting to quiz server!";
            }
        }
    }

    // starting the get next question route
    IEnumerator GetNextQuestion() {
        using (UnityWebRequest www = UnityWebRequest.Get($"{apiURL}/next-question/{sessionID}")) {
            yield return www.SendWebRequest();
            if (www.result == UnityWebRequest.Result.Success) {
                string jsonResponse = www.downloadHandler.text;
                QuestionResponse questionResponse = JsonUtility.FromJson<QuestionResponse>(jsonResponse);

                currentQuestionID = questionResponse.question_id;  // saves the current question id

                // display the questions in the ui
                questionText.text = questionResponse.question_text;
                difficultyText.text = $"Difficulty: {questionResponse.difficulty}";

                // show the user answer
                answerInput.text = "";
                feedbackText.text = "";

                // start timer for questions
                questionStartTime = Time.time;
            } else {
                Debug.LogError($"Error fetching next question! {www.error}");
                feedbackText.text= "error getting the next questions";
            }
        }
    }

    public void SubmitAnswer() {
        float responseTime = Time.time - questionStartTime;
        // a new answer request matching the pydantic model used in the original code
        AnswerRequest answerData = new AnswerRequest {
            question_id = currentQuestionID,
            user_answer = answerInput.text,
            response_time = responseTime
        };
        // send the answer back to the python server
        StartCoroutine(SubmitAnswerCoroutine(answerData));
    }

    IEnumerator SubmitAnswerCoroutine(AnswerRequest answerData) {
        string jsonData = JsonUtility.ToJson(answerData);
        using (UnityWebRequest www = new UnityWebRequest($"{apiURL}/submit-answer/{sessionID}", "POST")) {
                byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
                www.uploadHandler = new UploadHandlerRaw(bodyRaw); // new handler for raw text data from user
                www.downloadHandler = new DownloadHandlerBuffer();
                www.SetRequestHeader("Content-Type", "application/json");

                yield return www.SendWebRequest();
                if (www.result == UnityWebRequest.Result.Success) {
                    string jsonResponse = www.downloadHandler.text;
                    AnswerResponse answerResponse = JsonUtility.FromJson<AnswerResponse>(jsonResponse);
                    scoreText.text = $"Score: {answerResponse.score}/{answerResponse.total_questions}";

                    if (answerResponse.is_correct) {
                        feedbackText.text = "Correct!";
                        feedbackText.color = Color.green;
                    } else {
                        feedbackText.text = $"Incorrect. The correct answer is {answerResponse.correct_answer}";
                        feedbackText.color = Color.red;
                    }

                    // if the difficulty of the question has been updated
                    if (answerResponse.difficulty_changed) {
                        StartCoroutine(DifficultyChanged(answerResponse.new_difficulty));
                    }

                    // start the next question with a sligh delay
                    StartCoroutine(NextQ(2.0f));
                }
                else {
                    Debug.LogError($"Error submitting answer: {www.error}");
                    feedbackText.text = "error submitting answer";
                }
            }
        }

        IEnumerator DifficultyChanged(int new_difficulty) {
            string message = new_difficulty > int.Parse(difficultyText.text.Split(':')[1].Trim())
                ? "Difficulty Increased!"
                : "Difficulty adjusted to more appropriate level";
            TMP_Text difficultyChangedText = Instantiate(feedbackText, feedbackText.transform.parent);
            difficultyChangedText.text = message;
            difficultyChangedText.color = Color.blue;
            difficultyChangedText.transform.position += new Vector3(0, -30, 0);

            yield return new WaitForSeconds(3.0f);
            Destroy(difficultyChangedText.gameObject);
        }

        IEnumerator NextQ(float delay) {
            yield return new WaitForSeconds(delay);
            StartCoroutine(GetNextQuestion());
        }

        public void EndQuiz() {
            StartCoroutine(EndSession());
        }

        IEnumerator EndSession()
    {
        using (UnityWebRequest www = UnityWebRequest.PostWwwForm($"{apiURL}/end-session/{sessionID}", ""))
        {
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                string jsonResponse = www.downloadHandler.text;
                EndSessionResponse endResponse = JsonUtility.FromJson<EndSessionResponse>(jsonResponse);
                
                // Show final results
                questionText.text = "Quiz Complete!";
                feedbackText.text = $"Final Score: {endResponse.final_score}\nPercentage: {endResponse.score_percentage}\nTime: {endResponse.session_duration}";
                feedbackText.color = Color.black;
                
                // Disable input
                answerInput.interactable = false;
                submitButton.interactable = false;
            }
            else
            {
                Debug.LogError($"Error ending session: {www.error}");
            }
        }
    }
}
        