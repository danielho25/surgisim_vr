using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Microsoft.MixedReality.Toolkit.Experimental.UI;

public class showKeyBoard : MonoBehaviour
{
    public TMP_InputField inputField;

    void Start()
    {
        OpenKeyboard();
        Debug.Log("Keyboard Output");
    }

    public void OpenKeyboard() 
    {
        NonNativeKeyboard.Instance.InputField = inputField;
        NonNativeKeyboard.Instance.PresentKeyboard(inputField.text);
    }
}
