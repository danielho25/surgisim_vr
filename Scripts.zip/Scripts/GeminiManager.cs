using System.Collections;
using UnityEngine.Networking;
using UnityEngine;

[System.Serializable]
public class GeminiRequest {
    public string prompt;
}

[System.Serializable] // Add this to make JSON deserialization work properly
public class GeminiResponse {
    public string user_prompt;
    public string gemini_response;
}

public class GeminiManager : MonoBehaviour {
    public string apiURL = "http://localhost:8000/return-prompt";
    [SerializeField] public string apiKey = "";

    public delegate void ChatResponseReceived(string response);
    public event ChatResponseReceived OnChatResponseReceived;

    
    public void SendPrompt(string user_prompt) {
        StartCoroutine(send_prompt_coroutine(user_prompt));
    }

    private IEnumerator send_prompt_coroutine(string user_prompt) {
        GeminiRequest requestData = new GeminiRequest {
            prompt = user_prompt
        };
        string jsonData = JsonUtility.ToJson(requestData);

        UnityWebRequest request = new UnityWebRequest(apiURL, "POST");
        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
        request.uploadHandler = new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        
        if (!string.IsNullOrEmpty(apiKey)) {
            request.SetRequestHeader("Authorization", $"Bearer {apiKey}");
        }

        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success) {
            Debug.LogError("Error sending request: " + request.error);
        }
        else {
            Debug.Log("Request sent successfully: " + request.downloadHandler.text); 
            GeminiResponse response = JsonUtility.FromJson<GeminiResponse>(request.downloadHandler.text);
            OnChatResponseReceived?.Invoke(response.gemini_response);
        }
    }

    private void InterpretResponse(string reply) {
        Debug.Log("Response: " + reply);
    }
}