import csv
import random
import datetime
import numpy as np
from io import StringIO
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import os

sample_data = """question,answer,score
What is the term for the process of making an incision in the skin during surgery?,Incision,0
"What does the prefix ""hypo-"" mean in medical terminology?",Below normal or deficient,0
What body system includes the heart and blood vessels?,Cardiovascular system,0
"What does the suffix ""-itis"" indicate in medical terminology?",Inflammation,0
What is the medical term for a blood clot?,Thrombus,0
What organ is responsible for producing insulin?,Pancreas,0
"What does the term ""bilateral"" mean in medical context?",Affecting both sides,0
What is the membrane that surrounds the lungs called?,Pleura,1
What is the medical term for excessive thirst?,Polydipsia,1
"What does the prefix ""tachy-"" refer to in medical terminology?",Rapid or fast,1
What is the medical term for the voice box?,Larynx,1
What is the medical term for the process of converting food into energy?,Metabolism,1
"What does the term ""idiopathic"" mean in medical diagnosis?",Of unknown cause,1
What is the medical term for the collarbone?,Clavicle,1
What is the name of the membrane that surrounds the heart?,Pericardium,2
"What does the term ""sequela"" refer to in medical context?",A condition that follows as a consequence of a disease,2
What is the medical term for the surgical creation of an opening between two hollow organs?,Anastomosis,2
"What does the term ""prodromal"" refer to in disease progression?",Early symptoms indicating onset of disease,2
What is the term for abnormal backward flow of blood through a valve?,Regurgitation,2
What is the medical term for the layer between the epidermis and subcutaneous tissue?,Dermis,2"""


class ml_quiz:
    def __init__(self, quiz_data, training_data):
        # questions organized by difficulty
        self.questions_by_difficulty = {
            0: [],
            1: [],
            2: []
        }

        # model state management
        self.ml_model = None  # store the machine learning model
        self.feature_scaler = StandardScaler()  # normalize data
        self.current_difficulty = 0  # current difficulty of the question
        self.score = 0  # users current score
        self.num_questions_asked = 0  # number of questions asked

        self.training_data_path = training_data

        # feature extraction
        self.session_details = []  # stores the details of the session history (question content, user answers, correct or not
        self.session_start_time = None  # tracks session start time
        self.session_end_time = None

        # feature extraction (tracks user performance)
        self.user_features = {
            'correct_ratio': 0.0,  # ratio of correct questions
            'avg_response_time': 0.0,  # response time of each question in seconds
            'consecutive_correct': 0,  # how many questions correct in a row
            'difficulty_performance': {0: 0.5, 1: 0.5, 2: 0.5}  # performance at each difficulty level
        }

        # load the questions from the provided data
        self.load_questions(quiz_data)

        # initialize and train model if the is data
        if training_data:
            self.initialize_ml_model(training_data)

    # load the questions and parse data from csv
    def load_questions(self, data):
        # create a csv reader object
        csv_reader = csv.reader(StringIO(data))  # create a new csv reader object
        next(csv_reader)  # skip the headers in the csv

        question_id = 0  # counter to assign a number to each question
        for row in csv_reader:
            question, answer, difficulty = row
            difficulty = int(difficulty)  # cast the difficulty to an int

            # extract topic using the keywords
            # topic = self.extract_topic(question)

            # store the questions with a unique id, text, correct answer, difficulty, topic area
            self.questions_by_difficulty[difficulty].append(
                {
                    'question': question,
                    'answer': answer,
                    'difficulty': difficulty,
                    'avg_response_time': 0
                }
            )
            question_id += 1  # increment the question count by 1 (moves to the next question)

    def initialize_ml_model(self, training_data_path):
        try:
            training_features, training_labels = self.load_training_data(training_data_path)

            # split the features for model performance, train the model on one set of data
            X_train, X_test, y_train, y_test = train_test_split(training_features, training_labels, test_size=0.15, random_state=42)

            # scale features
            self.feature_scaler.fit(X_train)
            X_train_scaled = self.feature_scaler.transform(X_train)
            X_test_scaled = self.feature_scaler.transform(X_test)

            # set up the random forest classifier ml model
            self.ml_model = RandomForestClassifier(
                n_estimators=50,  # use 100 decision trees
                max_depth=5,  # limit each tree to a depth of 10 nodes
                min_samples_split=3,  # require 3 samples to split a node
                min_samples_leaf=2,
                # bootstrap=2,
                random_state=42
            )
            self.ml_model.fit(X_train_scaled, y_train)  # train the model using the scaled x data and labels for that data

            # evaluate performance of the model
            y_pred = self.ml_model.predict(X_test_scaled)
            model_accuracy = accuracy_score(y_test, y_pred)
            print("Model Initialized!")
            print(f"model accuracy: {model_accuracy:.2f}")

            # cross validation used for better evaluation of smaller dataset
            from sklearn.model_selection import cross_val_score
            cross_validated_scores = cross_val_score(self.ml_model, self.feature_scaler.transform(training_features),
                                                     training_labels, cv=3)  # 3-fold vector (data split into 5 different parts, trained on 4 parts, tested on the remainder. process repeats 5 times using different part for testing.
            print(f"Cross Validated ML score (the avg of all 5 cv scores): {cross_validated_scores.mean():.2f}")
            return True
        except Exception as e:
            print(f"Error Initialzing Model: {e}")
            print("Using rule based difficulty")
            return False


    def load_training_data(self, filepath):
        try:
            # if not os.path.exists(filepath):  # check if the file exists
            #     print("Error, No path found")
            #     return self.generate_sample_data()

            features = []  # store the data
            labels = []

            with open(filepath, 'r') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    feature_vector = [
                        float(row['correct_ratio']),
                        float(row['avg_response_time']),
                        float(row['consecutive_correct']),
                        float(row['difficulty'])
                    ]
                    features.append(feature_vector)
                    label = int(row['optimal_difficulty'])
                    labels.append(label)

                # if not features: # if there are no training data csv
                #     print("No valid data found!")
                #     return self.generate_sample_data()
                print(f"training data loaded with {len(features)} samples")
                return np.array(features), np.array(labels)
        except Exception as e:
            print(f"error loading data: {e}")
            # return self.generate_sample_data()

    # def generate_sample_data(self):
    #     print("Generating simulated data...")
    #
    #     features = np.random.rand(1000, 5)
    #     features[:, 4] = np.floor(features[:, 4] * 3)
    #     labels = np.zeros(1000)
    #
    #     for i in range(1000):
    #         correct_ratio = features[i, 0]
    #         response_time = features[i, 1]
    #         difficulty = features[i, 4]
    #
    #         if correct_ratio > 0.8 and response_time < 0.4:
    #            labels[i] = 0 if difficulty < 1.5 else 1
    #         elif correct_ratio < 0.4 or response_time > 0.8:
    #             labels[i] = 2 if difficulty > 0.5 else 1
    #         else:
    #             labels[i] = 1
    #
    #     print(f"simulated training data generated: {len(features)}")
    #     return features, labels


    def extract_features(self, question, user_answer, response_time, is_correct):
        if is_correct:
            self.user_features['consecutive_correct'] += 1
        else:
            self.user_features['consecutive_correct'] += 0

        alpha = 0.3
        difficulty = question['difficulty']
        self.user_features['difficulty_performance'][difficulty] = (
            alpha * (1 if is_correct else 0) +
            (1 - alpha) * self.user_features['difficulty_performance'][difficulty]
        )

        total_questions = len(self.session_details)
        if total_questions == 0:  # First question
            feature_vector = [
                1.0 if is_correct else 0.0,  # correct_ratio
                response_time,  # avg_response_time
                1 if is_correct else 0,  # consecutive_correct
                question['difficulty']  # difficulty
            ]
        else:
            # Update metrics based on history
            correct_count = sum(1 for q in self.session_details if q['is_correct'])
            self.user_features['correct_ratio'] = correct_count / total_questions

            # update avg response time with moving average
            self.user_features['avg_response_time'] = (
                    alpha * response_time +
                    (1 - alpha) * self.user_features['avg_response_time']
            )

            feature_vector = [
                self.user_features['correct_ratio'],
                self.user_features['avg_response_time'],
                self.user_features['consecutive_correct'],
                question['difficulty']
            ]

        return feature_vector

    def predict_optimal_difficulty(self, feature_vector):
        if self.ml_model is None:
            # Fall back to rule-based logic if no ML model is available
            return self.rule_based_difficulty_adjustment()

        try:
            print("Raw feature vector:", feature_vector)
            feature_vector_np = np.array(feature_vector, dtype=float)
            print("Converted to float:", feature_vector_np)
            if np.isnan(feature_vector_np).any():
                print("Nan values detected in feature vector! switching to rule based")
                return self.rule_based_difficulty_adjustment()


            feature_vector_2d = np.array(feature_vector).reshape(1,-1)
            # Scale the feature vector
            scaled_features = self.feature_scaler.transform([feature_vector])

            # Predict optimal difficulty category
            prediction = self.ml_model.predict(scaled_features)[0]

            # Adjust current difficulty based on prediction
            # 0 = too easy, 1 = appropriate, 2 = too hard
            if prediction == 0:  # Too easy
                return min(2, self.current_difficulty + 1)
            elif prediction == 2:  # Too hard
                return max(0, self.current_difficulty - 1)
            else:  # Appropriate
                return self.current_difficulty

        except Exception as e:
            print(f"Error in ML prediction: {e}")
            return self.rule_based_difficulty_adjustment()

    def rule_based_difficulty_adjustment(self):
        correct_ratio = self.user_features['correct_ratio']

        if correct_ratio > 0.8:
            return min(2, self.current_difficulty + 1)
        elif correct_ratio < 0.4:
            return max(0, self.current_difficulty - 1)
        else:
            return self.current_difficulty

    def next_question(self):
        if not self.questions_by_difficulty[self.current_difficulty]:
            available_difficulties = []
            for difficulty_level, questions in self.questions_by_difficulty.items():
                if questions:  # if there is available questions in this level
                    available_difficulties.append(difficulty_level)

            if not available_difficulties:
                return None

            # randomly select a difficulty level from the previous
            self.current_difficulty = random.choice(available_difficulties)

        # get a new random question from current difficulty
        selected_question = random.choice(self.questions_by_difficulty[self.current_difficulty])
        self.questions_by_difficulty[self.current_difficulty].remove(selected_question)  # remove the question of current difficulty
        return selected_question

    def check_answer(self, user_answer, correct_answer):
        return user_answer.lower().strip() == correct_answer.lower().strip()  # keywords

    def process_response(self, user_answer, correct_answer, response_time, question):
        is_correct = self.check_answer(user_answer, question['answer'])
        if is_correct:
            self.score += 1  # add 1 to the user score


        feature_vector = self.extract_features(question, user_answer, response_time, is_correct)
        # Record detailed interaction data
        interaction_data = {
            # 'question_id': question['id'],
            'question_text': question['question'],
            'difficulty_level': question['difficulty'],
            'user_answer': user_answer,
            'correct_answer': question['answer'],
            'is_correct': is_correct,
            'response_time': response_time,
            'cumulative_score': f"{self.score}/{self.num_questions_asked + 1}",
            'features': feature_vector
        }
        self.session_details.append(interaction_data)

        # Update question statistics
        # question['exposure_count'] += 1
        # if is_correct:
        #     question['correct_count'] += 1

        # Update average response time for this question
        alpha = 0.2  # Learning rate
        if question['avg_response_time'] == 0:
            question['avg_response_time'] = response_time
        else:
            question['avg_response_time'] = (
                    alpha * response_time +
                    (1 - alpha) * question['avg_response_time']
            )

        # Apply ML-based difficulty adjustment
        self.num_questions_asked += 1
        new_difficulty = self.predict_optimal_difficulty(feature_vector)

        # Log difficulty change for analysis
        difficulty_changed = new_difficulty != self.current_difficulty
        self.current_difficulty = new_difficulty

        return is_correct, difficulty_changed

    def save_results_to_csv(self, filename=None):
        if not self.session_details:
            print("No session data available to save!")
            return None

        # Generate default filename with timestamp if not provided
        if filename is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"ml_quiz_results_{timestamp}.csv"

        try:
            with open(filename, 'w', newline='') as csvfile:
                # Define the CSV structure
                fieldnames = [
                    'question',
                    'difficulty_level',
                    'is_correct',
                    'response_time',
                    'cumulative_score',
                ]

                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()

                # Write each record to CSV
                question_number = 1
                for record in self.session_details:
                    row_data = {
                        # 'question': question_number,
                        'difficulty_level': record['difficulty_level'],
                        # 'user_answer': record['user_answer'],
                        # 'correct_answer': record['correct_answer'],
                        'is_correct': record['is_correct'],
                        'response_time': f"{record['response_time']:.2f}",
                        'cumulative_score': record['cumulative_score'],
                    }
                    writer.writerow(row_data)
                    question_number += 1

                # Calculate and add summary statistics
                session_duration = 0
                if self.session_end_time and self.session_start_time:
                    session_duration = (self.session_end_time - self.session_start_time).total_seconds()

                final_score_percentage = 0
                if self.num_questions_asked > 0:
                    final_score_percentage = (self.score / self.num_questions_asked) * 100

                summary_row = {
                    # 'question_number': 'SUMMARY',
                    # 'question_text': f'Session Duration: {session_duration:.2f} seconds',
                    'difficulty_level': f'Final Difficulty: {self.current_difficulty}',
                    'is_correct': '',
                    'cumulative_score': f'Final Score: {self.score}/{self.num_questions_asked} ({final_score_percentage:.1f}%)'
                }
                writer.writerow(summary_row)

            print(f"Results successfully saved to {filename}")
            return filename

        except Exception as e:
            print(f"Error saving results: {e}")
            return None


    def update_model(self):
        if len(self.session_details) < 5:
            print("not enough data to satisfy model requirements!")
            return False
        try:
            appended_data = self.load_training_data(self.training_data_path)
            if not appended_data:
                print("error appending data")
                return False

            train_success = self.initialize_ml_model(self.training_data_path)
            if not train_success:
                print("failure to get training data!")

            save_success = self.save_model()
            if not save_success:
                print("Failed to save updated model")
            return False

            print("Model successfully updated with new session data")
            return True

        except Exception as e:
            # print(f"Error updating ML model: {e}")
            return False

    def save_model(self):
        try:
            import joblib
            # Save the model to a file
            joblib.dump(self.ml_model, 'quiz_model.joblib')
            # Save the scaler
            joblib.dump(self.feature_scaler, 'feature_scaler.joblib')
            print("Model successfully saved")
            return True
        except Exception as e:
            print(f"Error saving model: {e}")
            return False

    def start_session(self, question_limit = 10):
        self.score = 0
        self.num_questions_asked = 0
        self.session_details = []
        self.session_start_time = datetime.datetime.now()

        print("Welcome to the quiz system! This quiz will learn from user responses and adapt difficulties based on user repsonses")

        while self.num_questions_asked < question_limit:
            question = self.next_question()
            if question is None:
                print("no questions available!")
                break

            print(f"\nQuestion {self.num_questions_asked + 1}: {question['question']}")
            print(f"Difficulty: {question['difficulty']}")

            question_start_time = datetime.datetime.now()
            user_answer = input("Your Answer: ")
            response_time = (datetime.datetime.now() - question_start_time)

            is_correct, difficulty_changed = self.process_response(user_answer, question['answer'], response_time.total_seconds(), question)

            if is_correct:
                print("✓ Correct!")
            else:
                print(f"✗ Incorrect. The correct answer is: {question['answer']}")

            # Provide adaptive feedback based on ML insights
            if difficulty_changed:
                if self.current_difficulty > question['difficulty']:
                    print("System has increased the difficulty level for you.")
                else:
                    print("System has adjusted to a more appropriate difficulty level.")

            print(f"Current score: {self.score}/{self.num_questions_asked} | Response time: {response_time.total_seconds():.2f}s")

        self.session_end_time = datetime.datetime.now()
        session_duration = (self.session_end_time - self.session_start_time).total_seconds()

        print("Session Complete!")
        if self.num_questions_asked > 0:
            percentage = (self.score / self.num_questions_asked) * 100
        else:
            percentage = 0

        print(f"Final score: {self.score}/{self.num_questions_asked} ({percentage:.1f}%)")
        print(f"Session Duration: {session_duration:.2f} seconds")
        print(f"Final Difficulty Level: {self.current_difficulty}")

        print("updating Model based on results!")
        self.update_model()

        save_results = input("\nWould you like to save your results to a CSV file? (y/n): ")
        if save_results.lower().startswith('y'):
            filename = 'ml_quiz_results.csv'
            self.save_results_to_csv(filename)


if __name__ == "__main__":
    # Initialize the ML quiz system with a proper file path
    training_data_file = "quiz_training_data_2.csv"

    # Check if the file exists, if not, use "simulated" which will generate sample data
    if not os.path.exists(training_data_file):
        print(f"Training data file {training_data_file} not found. Using simulated data instead.")
        training_data = "simulated"
    else:
        training_data = training_data_file

    quiz = ml_quiz(sample_data, training_data=training_data)
    quiz.start_session()

