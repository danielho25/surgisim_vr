using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    public GameObject[] instruments;
    public GameObject hand;
    public TMP_Text quizText;
    public TMP_Text scoreText;
    public int score = 0;

    private GameObject correctInstrument;
    private GameObject givenInstrument;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        PickInstrument();
    }

    // Picks an instrument at random and updates the surgeon's text
    void PickInstrument()
    {
        correctInstrument = instruments[Random.Range(0, instruments.Length)];

        quizText.text = correctInstrument.name + ", please.";
    }

    // Snaps the instrument's position to the surgeon's hand
    void SnapInstrument(GameObject givenInstrument)
    {
        givenInstrument.transform.position = hand.transform.position;
        givenInstrument.transform.rotation = Quaternion.identity;
    }

    // Detects if an instrument is placed in the surgeon's hand, and checks if it's the right instrument
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.CompareTag("Instrument"))
        {
            givenInstrument = other.gameObject;

            SnapInstrument(givenInstrument);

            if(givenInstrument == correctInstrument)
            {
                score++;
                Debug.Log("Correct. Score: " + score);
            }
            else
            {
                score--;
                Debug.Log("Incorrect. Score: " + score);
            }

            scoreText.text = "Score: " + score;

            givenInstrument.GetComponent<Instrument>().ResetPosition();

            Invoke("PickInstrument", 1f);
        }
    }
}
