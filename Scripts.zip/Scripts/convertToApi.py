from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import datetime
import random
from typing import List, Optional, Dict, Any
import uvicorn
# import numpy as np

from scoring_m import ml_quiz, sample_data  # import the ml quiz from scoring_m.py

app = FastAPI(title="ML quiz app", description="Creating the api for the ml quiz app")

# initialize the quiz
quiz = ml_quiz(sample_data, training_data="quiz_training_data_2.csv")

# data and response for request/response
class AnswerRequest(BaseModel):
    question_id: str
    user_answer: str
    response_time: float

class QuestionResponse(BaseModel):
    question_id: str
    question_text: str
    difficulty: int

class AnswerResponse(BaseModel):
    is_correct: bool
    correct_answer: str
    score: int
    total_questions: int
    difficulty_changed: bool
    new_difficulty: int


# Store session data
sessions = {}  # keeps track of current session data
question_map = {}  # maps a question id to an actual question object

# Generate a unique ID for each question
for difficulty, questions in quiz.questions_by_difficulty.items():   # go through dict questions_by_dictionary from scoring_m
    for id, question in enumerate(questions):  # gets the id and the question, puts them in a list of enumerable data
        question_id = f"diff{difficulty}_q{id}"  # set the question and question od
        question_map[question_id] = question   # ex: quesiton_id : "question"


# returns the intro message
@app.get("/")
async def root():
    return {"message": "Welcome to ML Quiz API", "status": "active"}


# create a new session for the quiz, same as the user features section
@app.post("/start-session", response_model=dict)
async def start_session():
    session_id = f"session_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"

    # Initialize session data
    sessions[session_id] = {
        "score": 0,
        "num_questions_asked": 0,
        "session_details": [],
        "session_start_time": datetime.datetime.now(),
        "current_difficulty": 0,
        "user_features": {
            'correct_ratio': 0.0,
            'avg_response_time': 0.0,
            'consecutive_correct': 0,
            'difficulty_performance': {0: 0.5, 1: 0.5, 2: 0.5}
        }
    }

    return {"session_id": session_id, "message": "Session started successfully"}

# gets the next question from the session
@app.get("/next-question/{session_id}", response_model=QuestionResponse)
async def get_next_question(session_id: str):
    if session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")

    session = sessions[session_id]
    difficulty = session["current_difficulty"]

    # Find available questions at current difficulty
    available_questions = [q_id for q_id, q in question_map.items()
                           if q['difficulty'] == difficulty and q_id not in session.get("used_questions", [])]

    if not available_questions:
        # Try other difficulties if no questions at current level
        for diff in [0, 1, 2]:
            available_questions = [q_id for q_id, q in question_map.items()
                                   if q['difficulty'] == diff and q_id not in session.get("used_questions", [])]
            if available_questions:
                session["current_difficulty"] = diff
                break

    if not available_questions:
        raise HTTPException(status_code=404, detail="No more questions available")

    # Select random question
    question_id = random.choice(available_questions)
    question = question_map[question_id]

    # Mark question as used
    if "used_questions" not in session:
        session["used_questions"] = []
    session["used_questions"].append(question_id)

    return QuestionResponse(
        question_id=question_id,
        question_text=question["question"],
        difficulty=question["difficulty"]
    )

#
@app.post("/submit-answer/{session_id}", response_model=AnswerResponse)
async def submit_answer(session_id: str, answer_req: AnswerRequest):
    if session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")

    session = sessions[session_id]
    question_id = answer_req.question_id

    if question_id not in question_map:
        raise HTTPException(status_code=404, detail="Question not found")

    question = question_map[question_id]

    # Process the response using the quiz logic
    user_answer = answer_req.user_answer
    response_time = answer_req.response_time

    # Check if answer is correct
    is_correct = quiz.check_answer(user_answer, question["answer"])

    if is_correct:
        session["score"] += 1

    # Extract features for ML model
    feature_vector = quiz.extract_features(question, user_answer, response_time, is_correct)

    # Record interaction data
    session["num_questions_asked"] += 1
    interaction_data = {
        'question_text': question['question'],
        'difficulty_level': question['difficulty'],
        'user_answer': user_answer,
        'correct_answer': question['answer'],
        'is_correct': is_correct,
        'response_time': response_time,
        'cumulative_score': f"{session['score']}/{session['num_questions_asked']}",
        'features': feature_vector
    }
    session["session_details"].append(interaction_data)

    # Update difficulty using ML model
    old_difficulty = session["current_difficulty"]
    new_difficulty = quiz.predict_optimal_difficulty(feature_vector)
    session["current_difficulty"] = new_difficulty
    difficulty_changed = old_difficulty != new_difficulty

    return AnswerResponse(
        is_correct=is_correct,
        correct_answer=question["answer"],
        score=session["score"],
        total_questions=session["num_questions_asked"],
        difficulty_changed=difficulty_changed,
        new_difficulty=new_difficulty
    )


@app.get("/session-stats/{session_id}")
async def get_session_stats(session_id: str):
    if session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")

    session = sessions[session_id]

    # Calculate session duration
    session_duration = (datetime.datetime.now() - session["session_start_time"]).total_seconds()

    # Calculate score percentage
    if session["num_questions_asked"] > 0:
        score_percentage = (session["score"] / session["num_questions_asked"]) * 100
    else:
        score_percentage = 0

    return {
        "score": session["score"],
        "total_questions": session["num_questions_asked"],
        "score_percentage": f"{score_percentage:.1f}%",
        "session_duration": f"{session_duration:.2f} seconds",
        "current_difficulty": session["current_difficulty"]
    }


@app.post("/end-session/{session_id}")
async def end_session(session_id: str):
    if session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")

    session = sessions[session_id]
    session["session_end_time"] = datetime.datetime.now()

    # Calculate final stats
    session_duration = (session["session_end_time"] - session["session_start_time"]).total_seconds()

    if session["num_questions_asked"] > 0:
        score_percentage = (session["score"] / session["num_questions_asked"]) * 100
    else:
        score_percentage = 0

    # Generate filename and save results
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"ml_quiz_results_{timestamp}.csv"

    # quiz.save_results_to_csv(filename)

    final_stats = {
        "session_id": session_id,
        "final_score": f"{session['score']}/{session['num_questions_asked']}",
        "score_percentage": f"{score_percentage:.1f}%",
        "session_duration": f"{session_duration:.2f} seconds",
        "final_difficulty": session["current_difficulty"],
        "results_saved": False  # Set to True if you implement saving
    }


    return final_stats


if __name__ == "__main__":
    uvicorn.run("convertToApi:app", host="0.0.0.0", port=8000, reload=True)